﻿namespace BonusApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hi there. Run the unittests! Remember to debug.");
        }
    }
}